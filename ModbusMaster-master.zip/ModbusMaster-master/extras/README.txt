Documentation is available at:
  http://4-20ma.github.com/ModbusMaster

Alternatively, you can download the HTML files at:
  [tarball] https://github.com/4-20ma/ModbusMaster/tarball/gh-pages
  [zipball] https://github.com/4-20ma/ModbusMaster/zipball/gh-pages
